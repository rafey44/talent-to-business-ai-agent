# Product Photography

Basic product photography can be improved by:
- Using good lighting
- Keeping the product clearly visible
- Using a clean background
- Taking multiple useful angles
- Showing important product details
- Keeping the image focused on the actual product