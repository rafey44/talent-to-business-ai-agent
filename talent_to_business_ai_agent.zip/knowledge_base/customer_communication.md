# Customer Communication

Good customer communication should:
- Respond clearly and politely
- Answer questions honestly
- Confirm important order details
- Avoid promising things that are not confirmed
- Collect useful customer feedback
- Clearly communicate known product information