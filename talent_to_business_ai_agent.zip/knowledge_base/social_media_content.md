# Social Media Content

Useful handmade-product content can include:
- Product introduction posts
- Product photos
- Behind-the-scenes content
- Product details
- Honest customer-focused descriptions
- Calls to action

Content should describe the actual product without inventing features or claims.