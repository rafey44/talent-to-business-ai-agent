# Basic Product Pricing

A handmade product price should consider:
- Material cost
- Labor cost
- Packaging cost
- Delivery cost
- Other relevant costs
- Desired profit margin

The seller should calculate actual costs before deciding a selling price.
Pricing calculations should use known costs rather than guessed market prices.